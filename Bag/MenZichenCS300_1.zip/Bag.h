#ifndef BAG_
#define BAG_
#include <vector>

/**
 * The base class for all types of bags.
 *
 * @author Zichen Men <zichen.men@bellevuecollege.edu>
 * @version ___1.0____
 */
template <class ItemType>
class Bag
{
protected:
    std::vector<ItemType> items; // A vector to store items of any data type
    int size;                    // An integer representing the current size of the bag

public:
    Bag();                 // Default constructor
    Bag(const int &_size); // Parameterized constructor

    virtual void addItem(const ItemType &item);
    virtual bool removeItem(const ItemType &item);
    bool checkEmpty() const;
    virtual void displayContents() const;
};

#include "Bag.cpp"

#endif
