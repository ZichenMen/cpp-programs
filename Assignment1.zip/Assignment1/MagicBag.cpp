#include "MagicBag.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
#include <string>
#include <type_traits>
#include <cstdint>

// Predefined string list of magical items
template <>
const std::vector<std::string> MagicBag<std::string>::stringMagicalItems = {
    "MagicItem1", "MagicItem2", "MagicItem3", "MagicItem4", "MagicItem5"};
// Predefined int list of magical items
template <>
const std::vector<int> MagicBag<int>::intMagicalItems = {
    10001, 20002, 30003, 40004, 50005};

// A default constructor to initialize the bag with an initial size
template <class ItemType>
MagicBag<ItemType>::MagicBag() : Bag<ItemType>()
{
}

// A parameterized constructor
template <class ItemType>
MagicBag<ItemType>::MagicBag(const int &_size) : Bag<ItemType>(_size)
{
}

// The specialized version remove method for string
template <>
bool MagicBag<std::string>::removeItem(const std::string &_item)
{
    std::srand(static_cast<unsigned>(std::time(nullptr)));
    int randomValue = std::rand() % stringMagicalItems.size();

    for (int i = 0; i < items.size(); i++)
    {
        if (items[i] == _item)
        {
            items[i] = stringMagicalItems[randomValue];
            return true;
        }
    }
    return false;
}

// The specialized version remove method for int
template <>
bool MagicBag<int>::removeItem(const int &_item)
{
    std::srand(static_cast<unsigned>(std::time(nullptr)));
    int randomValue = std::rand() % intMagicalItems.size();

    for (int i = 0; i < items.size(); i++)
    {
        if (items[i] == _item)
        {
            items[i] = intMagicalItems[randomValue];
            return true;
        }
    }
    return false;
}
