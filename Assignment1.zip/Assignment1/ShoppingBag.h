#ifndef SHOPPING_BAG
#define SHOPPING_BAG
#include "Bag.h"
#include <map>

/**
 * Derived class from Bag, represents a shopping bag with quantities
 *
 */
template <class ItemType>
class ShoppingBag : public Bag<ItemType>
{
private:
public:
    ShoppingBag();                                            // default constructor
    ShoppingBag(const int &_size);                            // parameterized constructor
    void addItem(const ItemType &_item, const int &quantity); // add specific quantity of item
};

#include "ShoppingBag.cpp"

#endif